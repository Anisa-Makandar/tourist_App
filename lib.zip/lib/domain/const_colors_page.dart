import 'package:flutter/material.dart';

class AppColors {
  static final Color primaryColor = Color(0xFFDE5A02);
}
